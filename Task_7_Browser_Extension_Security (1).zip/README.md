# Task 7: Identify and Remove Suspicious Browser Extensions

## Objective:
To identify and remove any potentially harmful browser extensions.

## Steps Taken:
1. Opened the Chrome Extension Manager.
2. Reviewed all installed extensions.
3. Identified and removed suspicious or unnecessary ones.
4. Restarted the browser and verified performance.
5. Documented the process with screenshots and a report.

## Suspicious Extension Removed:
- PDF Converter Pro (unverified source, excessive permissions)

## Files Included:
- `report.pdf` - Detailed analysis and documentation
- `screenshots/` - Actual screenshots from the task
