# Task 6 - Password Security Evaluation

## Objective
Understand what makes a password strong and test it against online password strength tools.

## Tools Used
- Online Password Strength Checkers (e.g., passwordmeter.com)

## Task Summary
1. Created multiple passwords with varying complexity.
2. Evaluated each password using password strength tools.
3. Collected feedback and scores.
4. Documented best practices for strong password creation.
5. Summarized common password attacks.
6. Included screenshots of evaluations.

## Key Concepts
- Password strength
- Brute force attacks
- Dictionary attacks
- Authentication
- Best practices

## Screenshots and Report
See the attached PDF report and screenshots.

