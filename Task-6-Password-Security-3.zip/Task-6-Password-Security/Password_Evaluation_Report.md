# Password Strength Evaluation Report

## Passwords Tested

| Password | Strength Score | Feedback |
|----------|----------------|----------|
| `password123` | Weak | Too common and lacks complexity. |
| `P@ssw0rd!` | Medium | Better, uses symbols and case variation. Still a known pattern. |
| `My$3cur3L0ngP@ss!` | Strong | Excellent strength with length, complexity, and randomness. |
| `letmein` | Very Weak | Commonly used password, easily guessable. |
| `#Xr9!qZ7$wL` | Very Strong | High entropy, strong against brute-force and dictionary attacks. |

## Best Practices Learned

- Use at least **12 characters**.
- Combine **uppercase**, **lowercase**, **numbers**, and **symbols**.
- Avoid **dictionary words**, **names**, and **repetitive patterns**.
- Use **passphrases** with a combination of unrelated words.
- Avoid reusing passwords across different sites.
- Consider using a **password manager** for secure storage and generation.

## Common Password Attacks

- **Brute Force Attack**: Trying all possible combinations.
- **Dictionary Attack**: Using a list of common passwords or words.
- **Phishing**: Tricking users into giving passwords.
- **Keylogging**: Capturing typed keystrokes through malware.

## Tips

- Longer = Stronger.
- Never use real personal data.
- Use Two-Factor Authentication (2FA) wherever possible.

