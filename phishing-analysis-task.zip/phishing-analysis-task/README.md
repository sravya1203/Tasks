# Phishing Email Analysis - Cyber Security Internship Task 2

## Objective
Analyze a phishing email sample to identify key indicators of phishing using spoofing detection, email header analysis, and suspicious link inspection.

## Deliverables
- Full analysis report
- Tools used
- Indicators found

## Tools Used
- MXToolbox Email Header Analyzer
- Whois Lookup
- Manual Link Hovering

## Report
See: [phishing_email_analysis.md](./phishing_email_analysis.md)

## Author
[Your Name]
