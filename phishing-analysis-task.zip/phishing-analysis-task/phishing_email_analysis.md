# Phishing Email Analysis Report

## Email Overview
**Subject:** Account Suspended - Immediate Action Required  
**Sender:** security@micros0ft-support.com  
**Body:**
> Dear User,  
Your account has been suspended due to suspicious activity.  
Click below to verify your identity:  
[Verify Now](http://fake-microsoft-login.com)  
Failure to act will result in permanent suspension.  
– Microsoft Security Team

---

## Phishing Indicators

| Indicator | Explanation |
|----------|-------------|
| Spoofed Email Address | The domain uses 'micros0ft' (with zero) instead of 'microsoft'. |
| Urgent Language | Threats like “Immediate Action” and “Account Suspension”. |
| Suspicious Link | Link doesn't point to an official Microsoft domain. |
| Grammar Errors | Slight awkward phrases. |
| Generic Greeting | No personalization — “Dear User”. |
| No Signature/Digital Auth | No SPF/DKIM verification found. |

---

## Tools Used
- MXToolbox Email Header Analyzer: https://mxtoolbox.com/EmailHeaders.aspx  
- Whois Lookup: https://whois.domaintools.com/  
- Link Inspection: Manual hover and copy

---

## Conclusion
This is a typical phishing attempt leveraging urgency and deception to trick users into clicking on malicious links and submitting credentials.
