# Task 8: Working and Understanding VPN

## Objective
Understand how a VPN works by using a free VPN service, connecting to a server, and verifying encrypted traffic.

## Steps Performed
1. Chose ProtonVPN (Free VPN service).
2. Installed and connected to a Netherlands server.
3. Verified IP before and after connection.
4. Browsed securely using encrypted tunnel.
5. Disconnected and compared IP/browsing speed.

## Files Included
- VPN_Report.pdf (Detailed report)
- Screenshots (Showing each step)
