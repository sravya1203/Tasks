# Nmap Network Scan - Cyber Security Internship Task

## Objective
Scan your local network for open ports to understand exposure and vulnerabilities using Nmap.

## Steps Performed

1. Identified local IP range using:
   ```
   ipconfig (Windows) or ifconfig/ip a (Linux/Mac)
   ```
2. Ran TCP SYN scan:
   ```
   nmap -sS 192.168.1.0/24
   ```
3. Collected and saved scan results.
4. Analyzed open ports and researched their associated services.
5. Noted potential vulnerabilities and how to mitigate them.

## Tools Used
- Nmap
- (Optional) Wireshark

## Scan Result Summary
- Host 192.168.1.1: Open ports 80 (HTTP), 443 (HTTPS)
- Host 192.168.1.50: Open ports 22 (SSH), 139/445 (Windows file sharing)
- Observed services: Web servers, SSH, Samba
- Risk analysis: Outdated services or unnecessary open ports could be exploited

## Interview Questions & Answers

**1. What is an open port?**  
An open port is a communication endpoint that accepts connections, often representing a running service.

**2. How does Nmap perform a TCP SYN scan?**  
It sends SYN packets and waits for SYN-ACK to detect open ports, without completing the handshake.

**3. What risks are associated with open ports?**  
They expose services which may be vulnerable if not patched or secured.

**4. Explain the difference between TCP and UDP scanning.**  
TCP scanning checks for connection-based services; UDP scanning checks datagram services and is slower due to lack of acknowledgment.

**5. How can open ports be secured?**  
By disabling unused services, enforcing firewalls, patching systems, and using port-based restrictions.

**6. What is a firewall’s role regarding ports?**  
Firewalls block or allow traffic on specific ports based on rules to protect the network.

**7. What is a port scan and why do attackers perform it?**  
A port scan probes a system for open ports. Attackers use it to find vulnerable entry points.

**8. How does Wireshark complement port scanning?**  
Wireshark captures real-time packets and helps verify scan activity, responses, and detect unusual traffic.

## Output
See `scan_results.txt` for example scan output.

## Screenshots
(Optional) Add terminal/Wireshark screenshots in `/screenshots`.
