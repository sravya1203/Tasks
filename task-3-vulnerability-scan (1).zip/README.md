# 🛡️ Task 3: Basic Vulnerability Scan

This repository contains the results of a basic vulnerability scan performed as part of a cybersecurity internship task.

## ✅ Objective
Perform a basic vulnerability scan on your local machine using free tools such as Nessus Essentials or OpenVAS.

## 📋 Contents
- `basic_vulnerability_scan_report.md`: Detailed scan report with key findings.
- Dummy screenshots of scan results.

## 🧰 Tool Used
Nessus Essentials

## 📅 Date
May 29, 2025
