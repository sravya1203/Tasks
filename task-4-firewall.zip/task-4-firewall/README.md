# Task 4: Setup and Use a Firewall

## Objective
Configure UFW on Linux to block/allow specific traffic and understand firewall basics.

## Steps Performed
- Enabled UFW
- Blocked Telnet (port 23)
- Allowed SSH (port 22)
- Tested connection
- Verified and deleted rules

## Screenshots
See `/screenshots` folder.

## Key Concepts
- Firewall
- UFW
- Network ports
